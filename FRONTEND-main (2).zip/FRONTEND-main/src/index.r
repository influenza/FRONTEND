# From CRAN
install.packages("geobr")
