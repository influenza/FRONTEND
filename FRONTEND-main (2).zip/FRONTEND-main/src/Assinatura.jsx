import { Link } from "react-router-dom"
import { Button } from "./button"
import { Navigate, useNavigate } from 'react-router-dom'

function Assinatura(props) {
  let navigate=useNavigate()

const lista = props.listas
console.log(typeof(props.listas))
console.log(props.listas)
return(
<>
<div text={props.assinatura} onClick={()=>{    navigate(`/equipevisao`)}} style={{width:"300px", opacity:"0.95",height:"460px", backgroundColor:"#fff", boxShadow:"4px 4px 4px 3px rgba(0, 0, 0, 0.2)", color:"black", borderRadius:"10px", marginLeft:"30px", marginTop:"20px"}}>
<div style={{width:"300px", height:"370px"}}>
<div style={{marginTop:"20px", fontWeight:"bold",fontSize:"30px"}}>{props.assinatura} </div>
<div style={{marginTop:"20px", marginBottom:"20px"}}><span style={{fontSize:"30px"}}> <span style={{fontWeight:"bold",fontSize:"35px"}}> {props.preco}</span>/mes</span></div>

{props.assinatura != "Gratis" && 
<div style={{fontWeight:"bold",fontSize:"19px"}}>
<ul style={{listStyle:"none",marginLeft:"-10px"}}>
<li style={{marginTop:"15px",}}>Plataforma Ecosynergy  </li>
<li style={{marginTop:"15px"}}>Gerenciamento de Equipe</li>
<li style={{marginTop:"15px"}}>Grafico de emissoes</li>
{props.listas.map((item, index) => (
  <li style={{marginTop:"10px"}} key={index}>{item}</li>
))}
</ul>

</div>
}
{props.assinatura == "Gratis" && 
<div style={{fontWeight:"bold",fontSize:"19px"}}>
<ul style={{listStyle:"none",marginLeft:"-10px"}}>
<li style={{marginTop:"10px"}}>Acesso total  </li>

</ul>

</div>
}
</div>


</div>
</>
)
}
export default Assinatura
