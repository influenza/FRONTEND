import React, { useEffect, useState, useRef } from "react";
import "./tabela.css";
import Dipath from "../diapbarra.png";
import Dimedia from "../diamedia.png";
import Diabpath from "../diabarra.png";
import Mapa from "./mapa.png";
import axios from "axios";
import { Link } from "react-router-dom";
import Cookies from 'js-cookie';
import { Button } from "./button";
import Metas from "./metas";
import { Chart, registerables } from 'chart.js';
Chart.register(...registerables);

export function Dashboard(props) {
  const [temp, Settemp] = useState("Diaria");
  const [array, Setarray] = useState();
  const [arrayan, SetarrayAn] = useState();
  const d = new Date();
  const [total, Settotal] = useState();
  const [data, setData] = useState(null);
  const [grafico, setGrafico] = useState("Pizza");
  const [elemento, setelemento] = useState(<img style={{width:"500px",height:"300px"}} src={Diabpath}/>);
  const [dataAn, setDatan] = useState(null);
  const [ante, setAnte] = useState(false);
  const [Metrica, setMetrica] = useState("Media");
  const chartRef = useRef(null);
  const chartRef2 = useRef(null);
  const chartRef3 = useRef(null);

  const [result, setResult] = useState("");

  const [dictemp, setDicttemp] = useState({"Diaria":0,"Semanal":1,"Mensal":2,"Anual":3});
  
  console.log();
  
  function metrica(e){
    console.log(mes);
    console.log(dia);
    console.log(dia > 10);
    console.log(e.target.value);
    setMetrica(e.target.value);
  }
  
  let horas = d.getHours();
  let dia = d.getDate();
  let mes = d.getMonth() + 1;
  let year = d.getFullYear(); 
  let minutos = d.getMinutes();
  
  function tempo(e) {
    Settemp(e.target.value);
  }
  
  function graficoMet(e){
    console.log(grafico === "Pizza")
    console.log(grafico === "Barra")

    console.log(Cookies.get().Metas);
    setGrafico(e.target.value);
    console.log(e.target.value);
    if(e.target.value === "Pizza"){
      setelemento(<img style={{width:"500px",height:"300px"}} src={Dipath}/>);
    } else if(e.target.value === "Barra"){
      setelemento(<img style={{width:"500px",height:"300px"}} src={Diabpath}/>);
    }else{
      setelemento(<img style={{width:"500px",height:"300px"}} src={Dimedia}/>);
    }
  }
  
  function tabelamun(valor){
    console.log(valor.target.value);
    if(valor.target.value === "Anterior"){
      fetchData();
      setAnte(true);
    } else {
      fetchData();
      setAnte(false);
    }
    console.log(ante);
  }

  
  const fetchData = async () => {
    try {
      const response = await axios.get("http://127.0.0.1:5000/dashboard");
      const stringData = response.data.message.replaceAll("]]]","]]");

      const correctedString = stringData.replace(/'/g, '"');
      
      setResult(JSON.parse(correctedString))      
     
      
      let data1 = response.data.message;
      Settotal(response.data.total);
      console.log(total);
      if (data1 !== null) {
        let newData = data1.replaceAll("[", "").replaceAll("'", "").replaceAll("],", ',' ).replaceAll("]]]", "");
        if (!ante){
          setData(newData);
          Setarray(newData.split(", "));
        } else {
          setDatan(newData);
          SetarrayAn(newData.split(", "));
        }
      }
      return response.data.message

    } catch (error) {
      console.error("Erro ao obter dados do servidor:", error);
    }
  };
  
  if(!Cookies.get().Metas){
    Cookies.set("Metas","0,0,0,0");
  }

  useEffect(() => {
    fetchData()
    console.log(grafico)
    console.log(result)
    let cores = []
    let valor = []
    let id = []
    for (let index = 0; index < result.length; index++) {
    id.push(result[index][0])      
    valor.push(result[index][1])
    cores.push(result[index][3])      


    }
      console.log(cores)
      
    console.log()
   console.log(result)
    console.log(total);
    const ctx = chartRef.current;


    if (ctx) {
      const chartInstance = new Chart(ctx, {
        type: 'bar',
        data: {
          labels: id,
          datasets: [{
            label: 'Emissao de gases em',
            data: valor,
            aspectRatio:4,
            borderWidth: 1,
            backgroundColor:cores,
            barThickness: 8, 
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,

          scales: {
              yAxes: [{
                  display: true,
                  ticks: {
                    beginAtZero: true,
                      min:200,
                      max:200,
                      stepSize: 1

                  }
              }]
          }
      }
      });

   
    
    }
  }, []);
  return ( 
    <>
      <div id="container">
        <div id="contable" style={{ display: "flex", flexDirection: "column" }}>
          <div
            style={{
              display: "flex",
              flexDirection: "row",
              justifyContent: "space-between",
              textAlign: "center",
            }}
          >
            <p style={{ marginLeft: "20px", textAlign: "left", fontSize: "30px", fontFamily: "Krona One , sans-serif", fontWeight: "bold" }}>Ecosynergy</p>

            <p style={{ marginRight: "20px", textAlign: "right", fontSize: "30px", fontFamily: "Krona One , sans-serif", fontWeight: "bold" }}>GrÃ¡ficos de emissÃµes de gases <input style={{border:"0px", backgroundColor:"transparent", fontSize:"30px"}} type="date" name="data" id="" value={
            (mes<10 && dia<10)?`${year}-0${mes}-${dia}`
            :mes<10?`${year}-0${mes}-${dia}`
            :`${year}-${mes}-0${dia}`} /></p>

          </div>
          <div id="faixa1" style={{ display: "flex", flexDirection: "row", justifyContent: "space-around" }}>
            <div style={{ backgroundColor: "white", width: "20vw", height: "20vh", marginLeft: "20px", borderRadius: "10px", paddingTop:"2vh" }}>
              <div style={{ flexDirection: "column", display: "flex" }}>
               <div style={{display:"flex",flexDirection:"row", justifyContent:"space-between"}}>
               <span style={{ fontSize: "30px", fontFamily: "Krona One , sans-serif", fontWeight: "bold", marginLeft:"1vw"}}>{temp}</span> 
               <div><select name="tempo" onChange={tempo} id="tempo" style={{ backgroundColor: "#D3D3D3", marginRight:"1vw", borderRadius: "10px",width: "4vw", height: "3vh" }}>
                  <option value="Diaria">Diaria</option>
                  <option value="Semanal">Semanal</option>
                  <option value="Mensal">Mensal</option>
                  <option value="Anual">Anual</option>
                </select></div>               
              </div>
                <div style={{display:"flex",alignItems:"center",justifyContent:"center"}}>
                <span style={{ fontSize: "26px", fontFamily: "Krona One , sans-serif", fontWeight: "bold", color: "#14B57A", marginTop:"4vh"}}>{`${total} toneladas`}</span>

                </div>
                <div className="barradash"style={total>Cookies.get().Metas ? {border:" #14B57A solid 3.5px",marginTop:"8.8vh"}:{ border:"#14B57A solid 3.5px",marginTop:"8.8vh"}}></div>
            </div>
               </div>

               <div style={{ backgroundColor: "white", width: "20vw", height: "20vh", marginLeft: "20px", borderRadius: "10px", paddingTop:"2vh" }}>
              <div style={{ flexDirection: "column", display: "flex" }}>
               <div style={{display:"flex",flexDirection:"row", justifyContent:"space-between"}}>
               <span style={{ fontSize: "30px", fontFamily: "Krona One , sans-serif", fontWeight: "bold", marginLeft:"1vw",marginBottom:"4vh"}}>Diferenca {temp}</span> 
                  
              </div>
              <div style={{display:"flex",textAlign:"center",justifyContent:"center"}}>

              {(((42580591/total).toFixed(3)-1)*100).toFixed(3) <0 &&
                <div style={{ fontSize: "26px", fontFamily: "Krona One , sans-serif", fontWeight: "bold", color: "red", }}>
    
                <span >{`${(((4258059/total).toFixed(3)-1)*100).toFixed(2)}% `}</span> <br />
    <span style={{marginTop:"2vh",}}>{`${(total-4258059)} toneladas`}</span>
    <div className="barradash"style={ {border:" #14B57A solid 3.5px", marginTop:"4.1vh"}}></div>

     
                
              
                </div>
            }
                {(((42580591/total).toFixed(3)-1)*100).toFixed(3)> 0 &&
                <div style={{ fontSize: "26px", fontFamily: "Krona One , sans-serif", fontWeight: "bold", color: "#14B57A"}}>
    <span >{`${(((4258059/total).toFixed(3)-1)*100).toFixed(2)}% `}</span> <br />
    <span style={{marginTop:"2vh"}}>{`${(total-4258059)} toneladas`}</span>
    <div className="barradash"style={ {border:" #14B57A solid 3.5px", marginTop:"5.5vh"}}></div>

                </div>
            }
              </div>
         
            </div>

               </div>
               <div style={{ backgroundColor: "white", width: "20vw", height: "20vh", marginLeft: "20px", borderRadius: "10px", paddingTop:"2vh" }}>
              <div style={{ flexDirection: "column", display: "flex" }}>
               <div style={{display:"flex",flexDirection:"row", justifyContent:"space-between"}}>
               <span style={{ textAlign: "left", fontSize: "28px",marginLeft:"20px", fontFamily: "Krona One , sans-serif", fontWeight: "bold", }}>Diferenca meta: </span><Link to="/metas"><button style={{fontSize:"15px",backgroundColor: "#D3D3D3", marginRight:"1vw", borderRadius: "10px",width: "4.5vw", height: "4.0vh" }}>Definir meta</button></Link>
                  
              </div>
              <div style={{display:"flex",textAlign:"center",justifyContent:"center"}}>
     
              {(((Cookies.get().Metas.split(",")[dictemp[temp]]/total).toFixed(3)-1)*100).toFixed(3) <0 &&
                <div style={{marginTop:"2vh"}}>
                           <span style={{ fontSize: "24px"}}>Meta: {Cookies.get().Metas.split(",")[dictemp[temp]]} toneladas
        </span><br />
                         <span style={{ fontSize: "24px", fontFamily: "Krona One , sans-serif", fontWeight: "bold", color: "red" }}> {`${(((Cookies.get().Metas.split(",")[dictemp[temp]]/total).toFixed(3)-1)*100).toFixed(3)}%`}  </span><br/>
                <span style={{ fontSize: "24px", fontFamily: "Krona One , sans-serif", fontWeight: "bold", color: "red" }}> {(Cookies.get().Metas.split(",")[dictemp[temp]]-total)} toneladas</span>
                <div className="barradash"style={{ border:"red solid 3.5px", marginTop:"4.7vh"}}></div>
                
                </div>
            }
                {(((Cookies.get().Metas.split(",")[dictemp[temp]]/total).toFixed(3)-1)*100).toFixed(3)> 0 &&
                <span>
                           <span style={{ fontSize: "24px"}}>Metas: {Cookies.get().Metas.split(",")[dictemp[temp]]} toneladas
        </span><br />
                   <span id="positivo">{`${(((Cookies.get().Metas.split(",")[dictemp[temp]]/total).toFixed(3)-1)*100).toFixed(3)}%`}</span> 
                   <span id="positivo">{`${(Cookies.get().Metas.split(",")[dictemp[temp]]-4258059)}`}</span>

                   <div className="barradash"style={{ border:"#14B57A solid 3.5px",marginTop:"2px",   marginTop:"5.5vh"}}></div>

                </span>
            }
              </div>
         
            </div>

               </div>
               <div style={{ backgroundColor: "white", width: "20vw", height: "20vh", marginLeft: "20px", borderRadius: "10px", paddingTop:"2vh" }}>
              <div style={{ flexDirection: "column", display: "flex" }}>
               <div style={{display:"flex",flexDirection:"row", justifyContent:"space-between"}}>
               <span style={{ fontSize: "30px", fontFamily: "Krona One , sans-serif", fontWeight: "bold", marginLeft:"1vw"}}>{temp} {Metrica}</span> 
               <div>
                <select name="tempo" onChange={metrica} id="tempo" style={{ backgroundColor: "#D3D3D3", marginRight: "20px", borderRadius: "10px", width: "4vw", height: "3vh" }}>
                  <option value="Media">Media</option>
                  <option value="Variancia">Variancia</option>
                  <option value="Minimo">Minimo</option>
                  <option value="Maximo">Maximo  </option>

                </select></div>               
              </div>
                <div style={{display:"flex",alignItems:"center",justifyContent:"center"}}>
                <span style={{ fontSize: "26px", fontFamily: "Krona One , sans-serif", fontWeight: "bold", color: "#14B57A", marginTop:"4vh"}}>{`${total} toneladas`}</span>

                </div>
                <div className="barradash"style={total>Cookies.get().Metas ? {border:" #14B57A solid 3.5px",marginTop:"8.8vh"}:{ border:"#14B57A solid 3.5px",marginTop:"8.8vh"}}></div>
            </div>
               </div>

                
  
    
       
          </div>
            <div style={{display:`flex`,flexDirection:"row",marginLeft:"20px",marginTop:"30px",justifyContent:"space-around"}}>
          <div style={{ flexDirection:"column", display: "flex", justifyContent: "center" }}>
          <div style={{backgroundColor: "white", width: "50vw", height: "32vh", marginRight: "20px", flexDirection:"row",borderRadius: "10px",display: "flex", justifyContent: "space-between" }}>
          <div style={{marginLeft:"20px"}}>
          <div style={{ width: "550px", height: "30vh", marginLeft:"10px", borderRadius: "10px", marginRight: "20px", marginBottom: "20px", display: "flex", alignItems: "center", justifyContent: "center" }}>

  <canvas ref={chartRef} style={{ width: "100%", height: "100%" }}></canvas>
          


              </div>

                </div>
  <div>
           
  <select name="tempo" onChange={graficoMet} id="tempo" style={{ backgroundColor: "#D3D3D3", borderRadius: "10px", width: "100px", marginRight:"20px", marginTop:"20px",height: "35px" }}>
                  <option value="Barra">Barra</option>
                  <option value="Pizza">Pizza</option>
                  <option value="Media">Media</option>
                </select>
               
  </div>
  
              </div>
              
              <div>
              </div>
              <div style={{backgroundColor: "white", width: "650px", height: "300px", marginRight: "20px",marginTop:"20px", flexDirection:"row",borderRadius: "10px",display: "flex", justifyContent: "space-between" }}>
              <img src={Mapa} style={{width:"500px", marginLeft:"20px"}}/>
            </div>
            </div>
            <div style={{display:"flex",flexDirection:"row", backgroundColor:"white", borderRadius:"10px"}}>
              
            <div style={{ display:"flex",flexDirection:"column", textAlign:"center",alignItems:'center',backgroundColor:"white", marginRight:"20px", borderRadius:"10px", height:"500px", overflow:"hidden",overflowY:"scroll", padding:"10px"}}>
  
            <table >
        <thead >
            <tr >
            <th>Dia do MÃªs</th>
        <th>Quantidade de GÃ¡s</th>
        <th>Porcentagem por dia</th>
        <th>Cor representada</th>
            </tr>
        </thead>
        <tbody >
        {array && ante == false ?
  array.map((item, index) => {
    
    // Verifica se o Ã­ndice Ã© mÃºltiplo de 4 para criar um novo grupo
    if (index % 4 === 0) {
      // Cria um novo grupo com os prÃ³ximos 4 elementos do array
      const group = array.slice(index, index + 4);
      // Mapeia os elementos do grupo para JSX
      return (
        <tr>
        <td>{group[0]}</td>
        <td>{group[1]}</td>
        <td>{group[2]}</td>
        <td>{group[3]}</td>

        </tr>

      );
    }
    // Retorna null se o Ã­ndice nÃ£o for mÃºltiplo de 4 para evitar renderizaÃ§Ã£o extra
    return null;
  }): arrayan && arrayan.map((item, index) => {
    // Verifica se o Ã­ndice Ã© mÃºltiplo de 4 para criar um novo grupo
    if (index % 4 === 0) {
      // Cria um novo grupo com os prÃ³ximos 4 elementos do array
      const group = arrayan.slice(index, index + 4);
      // Mapeia os elementos do grupo para JSX
      return (
        <tr>
        <td>{group[0]}</td>
        <td>{group[1]}</td>
        <td>{group[2]}</td>
        <td>{group[3]}</td>

        </tr>

      );
    }
    // Retorna null se o Ã­ndice nÃ£o for mÃºltiplo de 4 para evitar renderizaÃ§Ã£o extra
    return null;
  })
}

        </tbody>
    </table>
    <canvas id="myChart"></canvas>

            </div>

            </div>

</div>
<div>

</div>
        </div>
      </div>
    </>
  );
}

