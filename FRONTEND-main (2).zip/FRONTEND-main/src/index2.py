import index
al1= index.ANALISEDEDADOS()
result=index.pizza(index.ANALISEDEDADOS.dadosmes(al1,1))
print(result)