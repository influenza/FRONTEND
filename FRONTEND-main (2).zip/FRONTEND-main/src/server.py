from flask import Flask, jsonify
from flask_cors import CORS, cross_origin  # Importe a extensão CORS
import index

app = Flask(__name__)
CORS(app)



@app.route('/dashboard', methods=['POST',"GET"])
@cross_origin()
def dashboard():
        al1= index.ANALISEDEDADOS()
        result=index.valores(index.ANALISEDEDADOS.dadosmes(al1,1))
        return jsonify({'message': f'{[result[0][x] for x in range(len(result[0]))]}]','total': f'{result[1]}'})

if __name__ == "__main__":
    app.run(debug=True)
