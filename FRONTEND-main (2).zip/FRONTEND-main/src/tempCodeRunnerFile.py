from flask_cors import CORS, cross_origin  # Importe a extensão CORS
