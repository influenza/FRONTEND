export function termosuso(){
    return(
        <p>termos de uso</p>
    )
}