import { useState } from 'react'
import "./Login.css"
import axios from 'axios'
import { Button } from './button'
import { Link } from 'react-router-dom'
import { Ecosynergy } from './ecosynergy'
import { Input } from './input'
import jsCookie from 'js-cookie'
import Cookies from 'js-cookie'
import fundo from "./image.png"
import logo from "./logo.png"
import letraverde from "./letraverde.png"
import { Navigate, useNavigate } from 'react-router-dom'

function Equipe4() {
  let navigate=useNavigate()

  console.log(Cookies.get())
  const [nomeEqui, setNomeEqui] = useState("")
  const [Area, setArea] = useState("")
  const [Numfunc, setNumfunc] = useState("")
  

  function handleChangeEmail(event) {
    setNomeEqui(event)
  }
  function handleEnviar(){
    Cookies.set("NomeEqui",nomeEqui)
    Cookies.set("Numfunc",Numfunc)
    Cookies.set("Area", Area)
    console.log(Cookies.get())
    navigate(`/equipe3`)

  }

  return (
    <>

    <div style={{display:"flex", flexDirection:"column", backgroundImage: `url('${fundo}')`, width:"100vw", height:"100vh", backgroundSize:"cover", backgroundRepeat:"no-repeat", backgroundPositionX:"center",backgroundPositionY:"", justifyContent:"center",alignItems:"center",textAlign:"center"}}>
    <div style={{display:"flex",flexDirection:"row",marginTop:"-25vh", width:"100vw",}}>
<div style={{width:"50vw", display:"flex", alignItems:"center", textAlign:"left",justifyContent:"left", marginRight:"20px", fontSize:"20px"}}>  
<img src={`${logo}`} style={{width:"150px", height:"150px", marginRight:"20px"}} alt="" />
  <img src={`${letraverde}`} style={{width:"200px", height:"200px"}} alt="" /></div>

    </div>
    <div style={{backgroundColor:"white", width:"25vw", borderRadius:"17px",boxShadow:"4px 4px 4px 3px rgba(0, 0, 0, 0.2)",  height:"50vh"}}>
      <p style={{fontSize:"40px",marginBottom:"25px",marginTop:"45px", fontWeight:"bolder"}}>Crie sua equipe em segundos</p>
      <div style={{ justifyContent:"center", alignItems:"center",textAlign:"center", }}>

</div>
      <p style={{fontSize:"18px", marginLeft:"1.5vw", marginTop:"10px",marginBottom:"5px", textAlign:"left"}}>NOME DA EQUIPE</p>

      <Input className="inplog" value={nomeEqui}  style={{ padding:"0px 10px",border:"2px solid #aaa",borderRadius:"16px",fontSize:"18px",  height:"4.5vh",marginBottom:"5px", width:"21vw"}} Onchange={handleChangeEmail}/>
      <div style={{marginLeft:"1.5vw",justifyContent:"left",alignItems:"center",display:"flex",flexDirection:"row"}}>
    
      <div className='erros' style={{color:"#FF6300", opacity:"0", display:"flex", alignItems:"center",justifyContent:"center", fontSize:"12px"}}>
  
      </div>
     </div>
      <div>
      <p style={{fontSize:"18px", marginLeft:"1.5vw", textAlign:"left",marginBottom:"5px"}}>SETOR DA INDUSTRIA</p>
      <select name="setor" id="setor" style={{ padding:"0px 10px",border:"2px solid #aaa",borderRadius:"16px",fontSize:"18px",  height:"4.5vh",marginBottom:"5px", width:"22vw"}}  onChange={(e)=>{
        setArea(e.target.value)
      }}>
          <option value="textil">Textil </option>
          <option value="auto">Automobilistica </option>
          <option value="petro">PetroQuimica </option>
          <option value="farma">Farmaceutico </option>
          <option value="alime">Alimenticio</option>
          <option value="base">Base</option>
          <option value="sider">Siderugica</option>
          <option value="meta">Metalurgica</option>
          <option value="agro">Agropecuario</option>
          <option value="naval">Naval</option>
          <option value="eletro">eletroeletronica</option>
          <option value="outrasin">Trabalho em outras industrias</option>
          <option value="outrosse">Trabalho em outro setor da economia</option>
          
      
        </select>
      </div>
      <div>
      <p style={{fontSize:"18px", marginLeft:"1.5vw", textAlign:"left",marginBottom:"5px"}}>QUANTIDADE DE FUNCIONARIOS</p>
      <select name="setor" id="setor" style={{ padding:"0px 10px",border:"2px solid #aaa",borderRadius:"16px",fontSize:"18px",  height:"4.5vh",marginBottom:"5px", width:"22vw"}}  onChange={(e)=>{
        setNumfunc(e.target.value)
      }}>
                  <option value="1-50"> 1-50 </option>
          <option value="51-200"> 51-200  </option>
          <option value="201-500"> 201-500 </option>
          <option value="501-1000"> 501-1000 </option>
          <option value="1001-5000"> 1001-5000 </option>
          <option value="5001-10000"> 5001-10000 </option>
          <option value="10000-20000"> 10000-20000 </option>
          <option value="20001+"> 20001+ </option>
      
        </select>
      </div>
      <div style={{marginLeft:"1.5vw",justifyContent:"left",alignItems:"center",display:"flex",flexDirection:"row"}}>
     </div>
        <div>
        
        </div>
          <div>
          <Button func={handleEnviar} text={"Entrar"} style={{width:"18vw",height:"5.5vh", backgroundColor:"#279301",color:"white", fontWeight:"bold",borderRadius:"10px",border:"0px solid white"}}>Enviar</Button>

          </div>
        
    </div>
    
          </div>
    </>
  )
}

export default Equipe4