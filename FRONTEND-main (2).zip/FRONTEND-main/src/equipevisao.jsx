import Cookies from "js-cookie"
import { useEffect, useState } from "react"
import { Input } from "./input";
import { Button } from "./button";
import { Link } from "react-router-dom";
import InputPer from "./inputper";
import { Navigate, useNavigate } from 'react-router-dom'
import Navbar from "./navbarlateral";
import "./404.css"
export function EquipeVisao(props){
    let navigate=useNavigate()
    const [imageperfil, setImageperfil] = useState(null);
    const [text ,settext] =useState("normal")
    function handleEnviar(){
        console.log("casemiro")
        navigate(`/equipe4`)

    }
    const handleImageChange = (e) => {
    Cookies.set("NomeEqui",)

        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setImageperfil(reader.result);
            };
            reader.readAsDataURL(file);
        }
    };
    console.log(Cookies.get())

    return(
        <div style={{display:"flex", flexDirection:"row"}}>
            {Cookies.get().NomeEqui &&
             <div>
           <Navbar es={0}></Navbar>
            <div style={{ display:"flex",flexDirection:"row", width:"86vw"}}>
                <div style={{backgroundColor:"#DDD9CE", width:"100vw",marginLeft:"13%", height:"100%"}}>
                <div style={{justifyContent:"center",alignItems:"center",display:"flex",flexDirection:"column"}}>
                
                <div style={{textAlign:"left", justifyContent:"left", display:"flex"}}>

                </div>
                    <div style={{justifyContent:"space-between",alignItems:"center",display:"flex", flexDirection:"row", width:"70vw"}}>
                        
                    <p style={{fontSize:"40px"}}>Perfil da equipe </p>
                <Button type="button" text ="Redefinir dados" func={(()=>{
                    settext("text")
                })} style={{fontSize:"30px",width:"230px"}}></Button>

                    </div>
                    <div style={{ width:"70vw", display:"flex",flexDirection:"row", justifyContent:"space-between", textAlign:"center"}}>
                    <div style={{justifyContent:"left"}}>
                    <div style={{justifyContent:"center",display:"flex"}}>
                    <div style={{marginLeft:"20px",fontSize:"40px",backgroundImage:`url(${imageperfil})`,textAlign:"center", backgroundSize:"cover", backgroundPositionX:"center", backgroundPositionY:"center", backgroundColor:"#14B57A", width:"300px", height:"300px", borderRadius: "50%",justifyContent:"center",alignItems:"center", display:"flex"}}>

                {Cookies.get().NomeEqui.split("")[0].toUpperCase()}
            
        </div>
        <label htmlFor="image_uploads" style={{marginLeft:"-4vw",backgroundColor:"gray", width:"80px", height:"80px", borderRadius: "50%", justifyContent:"center", alignItems:"center", textAlign:"center", display:"flex", fontSize:"30px", overflow: "hidden" }}>  
                <input
                    onChange={handleImageChange}
                    type="file"
                    id="image_uploads"
                    name="image_uploads"
                    accept=".jpg, .jpeg, .png"
                    multiple
                    style={{display: "none"}}
                />
                <svg fill="#000000" height="35px" width="35px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" 
viewBox="0 0 29.978 29.978" xml:space="preserve">
<g>
<path d="M25.462,19.105v6.848H4.515v-6.848H0.489v8.861c0,1.111,0.9,2.012,2.016,2.012h24.967c1.115,0,2.016-0.9,2.016-2.012
v-8.861H25.462z"/>
<path d="M14.62,18.426l-5.764-6.965c0,0-0.877-0.828,0.074-0.828s3.248,0,3.248,0s0-0.557,0-1.416c0-2.449,0-6.906,0-8.723
c0,0-0.129-0.494,0.615-0.494c0.75,0,4.035,0,4.572,0c0.536,0,0.524,0.416,0.524,0.416c0,1.762,0,6.373,0,8.742
c0,0.768,0,1.266,0,1.266s1.842,0,2.998,0c1.154,0,0.285,0.867,0.285,0.867s-4.904,6.51-5.588,7.193
C15.092,18.979,14.62,18.426,14.62,18.426z"/>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
</g>
</svg>

            </label>
                    </div>
                    <p style={{fontSize:"30px", cursor:"pointer"}} onClick={()=>{
                        setImageperfil("")
                    }}>Remover</p>


                    </div>
              <div style={{fontSize:"30px", justifyContent:"space-around",flexDirection:"column",display:"flex",textAlign:"left ",alignItems:"center"}}>
              <div style={{display:"flex", flexDirection:"column"}}>
              
              <span style={{marginRight:"20px"}}>Nome da equipe:</span>
              <InputPer type={text} text={`${Cookies.get().NomeEqui}`}></InputPer>

              </div>
              <div style={{display:"flex", flexDirection:"column"}}>
              
              <span style={{marginRight:"20px",justifyContent:"right"}}>Membro fundador:</span>
              <InputPer type={text} text={`Gabriel`}></InputPer>
                </div>
            
                </div>

                </div>
                <div style={{ marginTop:"50px", borderTop: "2px solid black ", marginLeft: "20", marginRight: "20", width:"87vw" }}></div>


                <div style={{ marginBottom:"30px",width:"70vw", display:"flex",flexDirection:"row", justifyContent:"space-around", textAlign:"left",marginTop:"35px"}}>
                <div style={{display:"flex", flexDirection:"column"}}>
              <span style={{marginRight:"20px",justifyContent:"right",fontSize:"30px"}}>Numero de funcionarios:</span>

              <InputPer type={text} text={`${Cookies.get().NumFunc}`}></InputPer>

                </div>

                <div style={{display:"flex",fontSize:"30px", flexDirection:"column"}}>
              <span style={{marginRight:"20px"}}>Area da industria:</span>
              <InputPer type={text} text={`${Cookies.get().Area}`}></InputPer>

                </div >

                </div>
 


                <div style={{display:"flex",marginTop:"10px",flexDirection:"row",justifyContent:"space-around",marginBottom:"0px"}}>
                <div style={{display:"flex",fontSize:"30px", flexDirection:"column"}}>
              <span style={{marginRight:"20px"}}>Descricao</span>
              <InputPer type={text} text={`${Cookies.get().Desc}`} width="400px" height="250px" ></InputPer>

                </div >

               </div>
               {text == "text" &&
                <div style={{marginTop:"60px", marginBottom:"20px"}}>
                                             <Button type="button" text ="Confimar" func={(()=>{
                            settext("normal")
                        })} style={{fontSize:"30px",width:"230px"}}></Button>   
                            <Link to="/redefinirsenha">        
                        <Button type="button" text ="Redefinir senha" style={{fontSize:"30px",width:"230px"}}></Button>  
                            </Link>

                </div>
                }
                </div>

    
                </div>
            </div>
             </div>
            }
            {!Cookies.get().NomeEqui &&
            
            <div style={{ display:"flex",flexDirection:"row", width:"100vw"}}>
            <div style={{backgroundColor:"#DDD9CE", width:"100vw",marginLeft:"13%", height:"100vh", justifyContent:"center", textAlign:"center",alignItems:"center",display:"flex",flexDirection:"column"}}>
                <p style={{fontSize:"20px"}}>
                PARA PROSSEGUIR NA PLATAFORMA ECOSYNERGY É NECESSARIO CRIAR OU ENTRAR EM UMA EQUIPE
                </p>
                <Button func={handleEnviar} text={"Criar"} style={{width:"12vw", marginBottom:"2vh",height:"5.5vh", backgroundColor:"#14B57A",color:"white", boxShadow:"4px 4px 4px 3px rgba(0, 0, 0, 0.2)",fontWeight:"bold",borderRadius:"10px",border:"0px solid white"}}>Enviar</Button>
            </div>
        </div>
        
}
            
                    </div>

    );
}
