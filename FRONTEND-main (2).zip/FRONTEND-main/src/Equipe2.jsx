import { useState } from 'react'
import axios from 'axios'
import { Ecosynergy } from './ecosynergy'
import { Input } from './input'
import { Link } from 'react-router-dom'
import Cookies from 'js-cookie'
import { Button } from './button'
function Equipe2() {
  const [nomeEqui, setNomeEqui] = useState("")
  const [descEqui, setDescEqui] = useState("")
  const [convite, setconvite] = useState(0)


  function handleNomeEqui(event) {
    setNomeEqui(event)
  }
  function handleDescEqui(event) {
    setDescEqui(event)
  }
  function handleChangeSenha(event) {
    setSenha(event)
  }
  function handleCopy() {
    const texto = `localhost:5173/equipe/convite/${Cookies.get().Nome}`

    navigator.clipboard.writeText(texto)
      .then(() => alert('Texto copiado para a área de transferência: ' + texto))
      }
  function handleEnviar(){
    axios({
      method: "post",
      url: "http://159.223.132.87/leiturasmq7/",
      data:{Mq7Value:700}
    });
  }
  return (
    <>
      <Ecosynergy qbolas={4} bolas={2}> 
        <p>Convide membros a sua equipe, através do e-mail que por eles foram cadastrado</p>
        <Input id="NomeEqui" value={nomeEqui} place="Selecione o email do membro" Onchange={handleNomeEqui}></Input>
        <p>Lista de usuarios chamados para equipe</p>
        <div>
        <a style={{marginTop:"20px"}}>Copiar link de convinte: </a>
        <button onClick={handleCopy} id='texto'>Compartilhar link</button>
        </div>
        <div>
        <Link to="/equipe3">
          <Button style={{marginTop:"20px",marginRight:"20px"}} text="Enviar"></Button>
          </Link>
          <Link to="/equipe">
          <Button style={{marginTop:"20px"}} text="Voltar"></Button>
          </Link>
        </div>
      </Ecosynergy>
    </>
  )
}

export default Equipe2
