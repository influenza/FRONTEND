function burgerbutton(){
    <li><div class="container">
    <div class="bar1"></div>
    <div class="bar2"></div>
    <div class="bar3"></div>
    </div>
    </li>
}
export default burgerbutton