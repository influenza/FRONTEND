import { useState } from "react";
import "./tabela.css"
import Cookies from "js-cookie"
import { Input } from "./input";
import { Button } from "./button";
import InputPer from "./inputper";
import { Link } from "react-router-dom";
import Navbar from "./navbarlateral";



    export function TabelaPag(props){
        const [dia,setdata]= useState(21);
        const [mes,setmes]=useState(3);
        const [ano,setano]=useState(2024);
        const linhas = Array.from({ length: 186 }, (_,index) => index  );
        const data ={2:28,4:30, 6:30, 9:30, 11:30}
        const [imageperfil, setImageperfil] = useState(null);
        const [text ,settext] =useState("normal")
        const handleImageChange = (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onloadend = () => {
                    setImageperfil(reader.result);
                };
                reader.readAsDataURL(file);
            }
        };
    
        return(
            <div style={{display:"flex", flexDirection:"row", overflow:"hidden"}}>
          
            <Navbar es={3}></Navbar>
            a
                    <div style={{ display:"flex",flexDirection:"row", width:"86vw"}}>
                <div style={{backgroundColor:"#DDD9CE", width:"100vw",marginLeft:"13%", height:"100%", msScrollLimitXMax:"0px"}}>
                <div style={{justifyContent:"center",alignItems:"center",display:"flex",flexDirection:"column", width:"100vw"}}>
    
    <p className="EcoIconLetter" style={{ marginLeft:"20px",fontSize:"36px"}}>Tabela de Emissoes</p>
    <div id="tabtit">
    <div id="tabbotao">
    <p className="EcoIconLetter" style={{ marginLeft:"20px",fontSize:"22px"}}>Donwload da tabelas nos seguintes arquivos:</p>
    
    <div id="botoestab">
    <button id="PDF">PDF</button>
    <button id="excel">Excel</button>
    
    <button id="PowerBi">PowerBi</button>
    </div>
    </div>
    
    <div id="tabtip">
    <p className="EcoIconLetter" style={{ marginLeft:"20px",fontSize:"22px"}}>Selecione o tipo de gas:</p>
    
    <select name="Gases" style={{ backgroundColor: "#14B57A", borderRadius: "10px", width: "100px", height: "45px" }}>
    <option value="Carbono">Carbono</option>
    <option value="Buteno">Buteno</option>
    <option value="Incedio">Incedio</option>
    
    </select >
    </div>
    </div>
            <div>
            <div style={{display:"flex",flexDirection:"row", borderRadius:"10px", alignItems:"center", justifyContent:"center"}}>
                  
                  <div style={{ display:"flex",flexDirection:"column", textAlign:"center",alignItems:'center', marginRight:"20px", borderRadius:"10px", height:"500px", overflow:"hidden",overflowY:"scroll", padding:"10px",}}>
        
                  <table  style={{width:"900px"}} >
              <thead  >
                  <tr style={{backgroundColor:"#edede9"}} >
              <th>ID</th>
                  <th>Dia do Mês</th>
              <th>Quantidade de Gás</th>
              <th>Local</th>
                  </tr>
              </thead>
              <tbody >
              {linhas &&
        linhas.map((item, index) => {
          
    
            return (
              <tr>
              <td>{item}</td>
              <td>{"21/03/2007"}</td>
              <td>{"100000"}</td>
            <td>{"São Paulo SP Brazil"}</td>
              </tr>
      
            );
          
          // Retorna null se o índice não for múltiplo de 4 para evitar renderização extra
          return null;
        })
    }
      
              </tbody>
          </table>
      
                  </div>
                  </div>
        <div id="pag" style={{textAlign:"center",justifyContent:"center",alignItems:"center"}}>
            <Link to="/tabela/1">  
            <button style={{ width: "50px"}}><p>{"1"}</p></button>
            </Link>
            <Link to="/tabela/2">  
            <button style={{ width: "50px"}}><p>{"2"}</p></button>
            </Link>
            <Link to="/tabela/3">  
            <button style={{ width: "50px"}} ><p>{"3"}</p></button>
            </Link>
        <span>...</span>
        <Link>  
            <button style={{ width: "50px"}}><p>{"15"}</p></button>
            </Link>
            <Link>  
            <button style={{ width: "50px"}}><p>{">"}</p></button>
            </Link>
        </div>
                </div>
    
    
                </div>
            </div>
            
             </div>
             
        
           
            
                    </div>
        );
    }